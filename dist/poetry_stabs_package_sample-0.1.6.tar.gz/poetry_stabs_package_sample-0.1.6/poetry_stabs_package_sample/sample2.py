"""This is a sample module for the poetry_stabs_package_sample package."""
