# poetry-stabs-package-sample

パッケージ公開サンプル

```
poetry config repositories.testpypi https://test.pypi.org/legacy/
poetry publish -r poetry-stabs-package-sample
```

# 型を付ける

# テストを書く

# awesome linters

# documents

# publish package

pypa/gh-action-pypi-publish@release/v1 を使うと公開できる、pypi とは odic で連携してるっぽいので事前に pypi の設定が必要
https://docs.github.com/ja/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-pypi
